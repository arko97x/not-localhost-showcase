import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, CircleHelp, Mic, RotateCcw, Square } from 'lucide-react';

type SignalKey = 'hello' | 'danger' | 'safe' | 'leave';

type Cue = {
  key: SignalKey;
  sound: string;
  time: string;
};

type LogEntry = Cue & { id: number };

type RecognitionResultEvent = Event & {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      length: number;
      [index: number]: { transcript: string };
    };
  };
};

type RecognitionErrorEvent = Event & { error?: string };

type Recognition = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: RecognitionResultEvent) => void) | null;
  onerror: ((event: RecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

type SpeechWindow = Window & {
  SpeechRecognition?: new () => Recognition;
  webkitSpeechRecognition?: new () => Recognition;
  webkitAudioContext?: typeof AudioContext;
};

const SIGNALS: Array<{
  key: SignalKey;
  sound: string;
  description: string;
  tone: string;
}> = [
  { key: 'hello', sound: 'Vocal swell', description: 'sustained, soft open tone', tone: 'tone-amber' },
  { key: 'danger', sound: 'Triple click', description: 'three sharp alert pulses', tone: 'tone-coral' },
  { key: 'safe', sound: 'Ascending chime', description: 'two-note crystalline tone', tone: 'tone-mist' },
  { key: 'leave', sound: 'Falling whistle', description: 'descending directional tone', tone: 'tone-teal' },
];

const MASTER_OUTPUT_GAIN = 1.45;
const NORMALIZED_PEAK = 0.42;

const signalByKey = (key: SignalKey) => SIGNALS.find((signal) => signal.key === key) ?? SIGNALS[0];
const signalDuration = (key: SignalKey) => key === 'danger' ? 0.46 : key === 'safe' ? 0.92 : key === 'leave' ? 1.3 : 1.6;
const signalFromPath = (): SignalKey | null => {
  if (typeof window === 'undefined') return null;
  const key = window.location.pathname.match(/^\/signal\/(hello|danger|safe|leave)$/)?.[1];
  return (key as SignalKey | undefined) ?? null;
};

function formatTime(date = new Date()) {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function getAudioContextConstructor() {
  const audioWindow = window as SpeechWindow;
  return window.AudioContext || audioWindow.webkitAudioContext;
}

function createSignalGraph(
  context: BaseAudioContext,
  key: SignalKey,
  destination: AudioNode,
  now: number,
) {
  const masterOutput = context.createGain();
  masterOutput.gain.setValueAtTime(MASTER_OUTPUT_GAIN, now);
  masterOutput.connect(destination);

  if (key === 'hello') {
    const output = context.createGain();
    output.gain.setValueAtTime(0.0001, now);
    output.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + 0.18);
    output.gain.exponentialRampToValueAtTime(0.0001, now + 1.55);
    output.connect(masterOutput);
    const body = context.createOscillator();
    body.type = 'sine';
    body.frequency.setValueAtTime(205, now);
    body.frequency.linearRampToValueAtTime(218, now + 1.2);
    body.connect(output);
    body.start(now);
    body.stop(now + 1.6);
    const overtone = context.createOscillator();
    overtone.type = 'sine';
    overtone.frequency.setValueAtTime(410, now);
    const overtoneGain = context.createGain();
    overtoneGain.gain.value = 0.18;
    overtone.connect(overtoneGain);
    overtoneGain.connect(output);
    overtone.start(now);
    overtone.stop(now + 1.6);
    return;
  }

  if (key === 'safe') {
    const output = context.createGain();
    output.gain.value = 1;
    output.connect(masterOutput);
    [
      { frequency: 660, start: 0, duration: 0.42, level: 0.36, type: 'sine' as OscillatorType },
      { frequency: 990, start: 0.19, duration: 0.62, level: 0.3, type: 'triangle' as OscillatorType },
    ].forEach(({ frequency, start, duration, level, type }) => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      gain.gain.setValueAtTime(0.0001, now + start);
      gain.gain.exponentialRampToValueAtTime(level, now + start + 0.012);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration);
      oscillator.connect(gain);
      gain.connect(output);
      oscillator.start(now + start);
      oscillator.stop(now + start + duration + 0.02);
    });
    return;
  }

  if (key === 'danger') {
    const buffer = context.createBuffer(1, Math.floor(context.sampleRate * 0.07), context.sampleRate);
    const channel = buffer.getChannelData(0);
    for (let index = 0; index < channel.length; index += 1) {
      channel[index] = (Math.random() * 2 - 1) * (1 - index / channel.length);
    }
    [0, 0.14, 0.28].forEach((offset) => {
      const source = context.createBufferSource();
      source.buffer = buffer;
      const filter = context.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 1700;
      const gain = context.createGain();
      gain.gain.setValueAtTime(0.0001, now + offset);
      gain.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + offset + 0.008);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.07);
      source.connect(filter);
      filter.connect(gain);
      gain.connect(masterOutput);
      source.start(now + offset);
    });
    return;
  }

  const output = context.createGain();
  output.gain.setValueAtTime(0.0001, now);
  output.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + 0.08);
  output.gain.exponentialRampToValueAtTime(0.0001, now + 1.28);
  output.connect(masterOutput);
  const whistle = context.createOscillator();
  whistle.type = 'sine';
  whistle.frequency.setValueAtTime(980, now);
  whistle.frequency.exponentialRampToValueAtTime(280, now + 1.22);
  whistle.connect(output);
  whistle.start(now);
  whistle.stop(now + 1.3);
}

function SiteHeader() {
  return (
    <header className="nc-header">
      <div className="nc-mark" aria-label="Ec(ak)ou">
        <span className="nc-mark-glyph" aria-hidden="true"><span className="nc-live-dot" /></span>
        <span>
          <span className="nc-mark-name">Ec(ak)ou</span>
          <span className="nc-mark-sub">field prototype / 04</span>
        </span>
      </div>
      <div className="nc-header-meta">
        <span className="nc-live-dot" aria-hidden="true" />
        <span>local signal processing</span>
        <span>build 0.4.1</span>
      </div>
    </header>
  );
}

function SignalResult({
  signal,
  onBack,
}: {
  signal: (typeof SIGNALS)[number];
  onBack: () => void;
}) {
  const [imageFailed, setImageFailed] = useState(false);

  return (
    <div className="nc-shell nc-signal-shell">
      <SiteHeader />
      <main className="nc-main nc-signal-main">
        <button type="button" className="nc-back-button" onClick={onBack}>
          <ArrowLeft size={14} aria-hidden="true" /> Back to receiver
        </button>
        <section className="nc-result-intro" aria-labelledby="signal-result-title">
          <p className="nc-eyebrow">Signal translated / local artefact</p>
          <h1 className="nc-result-title" id="signal-result-title">SIGNAL<br /><span>CAPTURED.</span></h1>
          <p className="nc-result-subtitle">{signal.sound} · {signal.description}</p>
        </section>

        <section className="nc-result-grid" aria-label="Generated signal result">
          <div className="nc-spectrogram-frame">
            <div className="nc-result-label">Spectrogram / audio response</div>
            {!imageFailed ? (
              <img
                src={`/spectrograms/${signal.key}.png`}
                alt="Generated sound spectrogram"
                onError={() => setImageFailed(true)}
              />
            ) : (
              <div className="nc-spectrogram-missing" role="img" aria-label="Generated spectrogram image is not loaded yet">
                <span>IMAGE SLOT / SPECTROGRAM.PNG</span>
                <strong>Attach spectrogram</strong>
                <small>Place the supplied PNG in public/spectrograms.</small>
              </div>
            )}
            <div className="nc-spectrogram-axis"><span>0s</span><span>frequency →</span><span>{signalDuration(signal.key).toFixed(2)}s</span></div>
          </div>

        </section>
      </main>
    </div>
  );
}

function Home() {
  const [isListening, setIsListening] = useState(false);
  const [latestCue, setLatestCue] = useState<Cue | null>(null);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [cueActive, setCueActive] = useState(false);
  const [activeSignal, setActiveSignal] = useState<SignalKey | null>(signalFromPath);
  const recognitionRef = useRef<Recognition | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const listeningRef = useRef(false);
  const restartTimerRef = useRef<number | null>(null);
  const cueTimerRef = useRef<number | null>(null);

  const speechConstructor = typeof window !== 'undefined'
    ? ((window as SpeechWindow).SpeechRecognition ?? (window as SpeechWindow).webkitSpeechRecognition)
    : undefined;
  const audioSupported = typeof window !== 'undefined' && Boolean(getAudioContextConstructor());
  const microphoneSupported = typeof navigator !== 'undefined' && Boolean(navigator.mediaDevices?.getUserMedia);
  const browserSupported = Boolean(speechConstructor && audioSupported && microphoneSupported);

  const stopHardware = useCallback(() => {
    listeningRef.current = false;
    if (restartTimerRef.current !== null) {
      window.clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      recognitionRef.current.onend = null;
      recognitionRef.current.onerror = null;
      recognitionRef.current.onresult = null;
      try {
        recognitionRef.current.abort();
      } catch {
        // The recognition object may already be idle.
      }
      recognitionRef.current = null;
    }
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setIsListening(false);
  }, []);

  useEffect(() => () => {
    stopHardware();
    if (cueTimerRef.current !== null) window.clearTimeout(cueTimerRef.current);
  }, [stopHardware]);

  useEffect(() => {
    const handlePopState = () => setActiveSignal(signalFromPath());
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const openSignalPage = useCallback((key: SignalKey) => {
    window.history.pushState({ signal: key }, '', `/signal/${key}`);
    setActiveSignal(key);
  }, []);

  const returnToReceiver = useCallback(() => {
    window.history.pushState({}, '', '/');
    setActiveSignal(null);
    setLatestCue(null);
    setCueActive(false);
  }, []);

  const playSignal = useCallback(async (key: SignalKey) => {
    const AudioContextConstructor = getAudioContextConstructor();
    if (!AudioContextConstructor) return;
    const context = audioContextRef.current ?? new AudioContextConstructor();
    audioContextRef.current = context;
    await context.resume();
    const now = context.currentTime;
    const masterOutput = masterGainRef.current ?? context.createGain();
    if (!masterGainRef.current) {
      masterGainRef.current = masterOutput;
      masterOutput.connect(context.destination);
    }
    masterOutput.gain.setValueAtTime(MASTER_OUTPUT_GAIN, now);

    if (key === 'hello') {
      const output = context.createGain();
      output.gain.setValueAtTime(0.0001, now);
      output.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + 0.18);
      output.gain.exponentialRampToValueAtTime(0.0001, now + 1.55);
      output.connect(masterOutput);
      const body = context.createOscillator();
      body.type = 'sine';
      body.frequency.setValueAtTime(205, now);
      body.frequency.linearRampToValueAtTime(218, now + 1.2);
      body.connect(output);
      body.start(now);
      body.stop(now + 1.6);
      const overtone = context.createOscillator();
      overtone.type = 'sine';
      overtone.frequency.setValueAtTime(410, now);
      const overtoneGain = context.createGain();
      overtoneGain.gain.value = 0.18;
      overtone.connect(overtoneGain);
      overtoneGain.connect(output);
      overtone.start(now);
      overtone.stop(now + 1.6);
      return;
    }

    if (key === 'safe') {
      const output = context.createGain();
      output.gain.value = 1;
      output.connect(masterOutput);
      [
        { frequency: 660, start: 0, duration: 0.42, level: 0.36, type: 'sine' as OscillatorType },
        { frequency: 990, start: 0.19, duration: 0.62, level: 0.3, type: 'triangle' as OscillatorType },
      ].forEach(({ frequency, start, duration, level, type }) => {
        const oscillator = context.createOscillator();
        oscillator.type = type;
        oscillator.frequency.value = frequency;
        const gain = context.createGain();
        gain.gain.setValueAtTime(0.0001, now + start);
        gain.gain.exponentialRampToValueAtTime(level, now + start + 0.012);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration);
        oscillator.connect(gain);
        gain.connect(output);
        oscillator.start(now + start);
        oscillator.stop(now + start + duration + 0.02);
      });
      return;
    }

    if (key === 'danger') {
      const buffer = context.createBuffer(1, Math.floor(context.sampleRate * 0.07), context.sampleRate);
      const channel = buffer.getChannelData(0);
      for (let index = 0; index < channel.length; index += 1) {
        channel[index] = (Math.random() * 2 - 1) * (1 - index / channel.length);
      }
      [0, 0.14, 0.28].forEach((offset) => {
        const source = context.createBufferSource();
        source.buffer = buffer;
        const filter = context.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 1700;
        const gain = context.createGain();
        gain.gain.setValueAtTime(0.0001, now + offset);
        gain.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + offset + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + offset + 0.07);
        source.connect(filter);
        filter.connect(gain);
        gain.connect(masterOutput);
        source.start(now + offset);
      });
      return;
    }

    const output = context.createGain();
    output.gain.setValueAtTime(0.0001, now);
    output.gain.exponentialRampToValueAtTime(NORMALIZED_PEAK, now + 0.08);
    output.gain.exponentialRampToValueAtTime(0.0001, now + 1.28);
    output.connect(masterOutput);
    const whistle = context.createOscillator();
    whistle.type = 'sine';
    whistle.frequency.setValueAtTime(980, now);
    whistle.frequency.exponentialRampToValueAtTime(280, now + 1.22);
    whistle.connect(output);
    whistle.start(now);
    whistle.stop(now + 1.3);
  }, []);

  const registerSignal = useCallback((key: SignalKey) => {
    const signal = signalByKey(key);
    const cue = { key, sound: signal.sound, time: formatTime() };
    setLatestCue(cue);
    setLog((current) => [{ ...cue, id: Date.now() }, ...current].slice(0, 8));
    setCueActive(true);
    if (cueTimerRef.current !== null) window.clearTimeout(cueTimerRef.current);
    cueTimerRef.current = window.setTimeout(() => setCueActive(false), 1800);
    stopHardware();
    openSignalPage(key);
    void playSignal(key);
  }, [openSignalPage, playSignal, stopHardware]);

  const startListening = useCallback(async () => {
    if (!browserSupported || !speechConstructor) {
      setError('This browser does not provide the microphone, speech recognition, or audio tools this prototype needs.');
      return;
    }
    setError(null);
    try {
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
      const AudioContextConstructor = getAudioContextConstructor();
      if (!AudioContextConstructor) throw new Error('audio-unsupported');
      audioContextRef.current = audioContextRef.current ?? new AudioContextConstructor();
      await audioContextRef.current.resume();
      const recognition = new speechConstructor();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';
      recognition.onresult = (event) => {
        for (let index = event.resultIndex; index < event.results.length; index += 1) {
          const result = event.results[index];
          if (!result.isFinal) continue;
          const transcript = result[0]?.transcript.trim().toLowerCase() ?? '';
          const words = transcript.match(/[a-z]+/g) ?? [];
          if (words.length !== 1) continue;
          const match = SIGNALS.find((signal) => signal.key === words[0]);
          if (match) registerSignal(match.key);
        }
      };
      recognition.onerror = (event) => {
        if (event.error === 'no-speech' || event.error === 'aborted') return;
        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          stopHardware();
          setError('Microphone access was not granted. Allow microphone access in your browser settings, then try again.');
          return;
        }
        setError('The listening channel encountered an interruption. Press stop, then start again.');
      };
      recognition.onend = () => {
        if (!listeningRef.current) return;
        restartTimerRef.current = window.setTimeout(() => {
          try {
            recognition.start();
          } catch {
            // A recognizer can still be transitioning; the next end event will recover it.
          }
        }, 120);
      };
      recognitionRef.current = recognition;
      listeningRef.current = true;
      setIsListening(true);
      recognition.start();
    } catch (caughtError) {
      streamRef.current?.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      const denied = caughtError instanceof DOMException && (caughtError.name === 'NotAllowedError' || caughtError.name === 'SecurityError');
      setError(denied
        ? 'Microphone access was not granted. Allow microphone access in your browser settings, then try again.'
        : 'The microphone could not be opened. Check that another application is not holding it, then try again.');
      setIsListening(false);
      listeningRef.current = false;
    }
  }, [browserSupported, registerSignal, speechConstructor, stopHardware]);

  const clearState = () => {
    setLatestCue(null);
    setLog([]);
    setCueActive(false);
    setError(null);
  };

  const statusText = isListening ? 'Listening for four signals' : error ? 'Channel needs attention' : 'Microphone idle · press start to begin';

  if (activeSignal) {
    const signal = signalByKey(activeSignal);
    return (
      <SignalResult
        signal={signal}
        onBack={returnToReceiver}
      />
    );
  }

  return (
    <div className="nc-shell">
      <SiteHeader />

      <main className="nc-main">
        <section className="nc-intro" aria-labelledby="page-title">
          <div>
            <p className="nc-eyebrow">A private language for a world that listens too much</p>
            <h1 className="nc-title" id="page-title">SPEAK <span>HUMAN.</span></h1>
            <p className="nc-subheading">SPEAK <b>→</b> LISTEN <b>→</b> SIGNAL</p>
          </div>
          <p className="nc-intro-copy">
            Ec<span>(ak)</span>ou translates four spoken cues into signals that refuse to become ordinary language.
          </p>
        </section>

        <section className="nc-console nc-console--solo" aria-label="Communication console">
          <div className="nc-listening-panel">
            <div className="nc-panel-top">
              <span className="nc-kicker">Primary receiver / 01</span>
              <span className={`nc-status-pill ${isListening ? 'is-listening' : ''}`} data-testid="status-microphone">
                <span className="nc-pulse" aria-hidden="true" />
                {isListening ? 'Live' : 'Standby'}
              </span>
            </div>

            <div className={`nc-orbit ${isListening ? 'is-active' : ''}`}>
              <div className={`nc-core ${isListening ? 'is-active' : ''} ${cueActive ? 'is-cue' : ''}`}>
                <div className="nc-core-label" aria-live="polite" data-testid="status-listening">
                  <strong>{isListening ? 'Listening' : latestCue ? 'Signal ready' : 'At rest'}</strong>
                  <span>{isListening ? 'four cues / en-us' : 'microphone idle'}</span>
                </div>
              </div>
            </div>

            <div className="nc-meter" aria-hidden="true"><span className={isListening ? 'is-active' : ''} /></div>
            <div className="nc-panel-bottom">
              <span><strong>{statusText}</strong></span>
              <div className={`nc-cta-row ${isListening ? 'is-live' : ''}`}>
                <button
                  type="button"
                  className={`nc-button ${isListening ? 'stop' : 'primary'}`}
                  onClick={isListening ? stopHardware : startListening}
                  disabled={!browserSupported && !isListening}
                  aria-label={isListening ? 'Stop listening' : 'Start listening and grant microphone access'}
                  data-testid={isListening ? 'button-stop-listening' : 'button-start-listening'}
                >
                  {isListening ? <><Square size={13} aria-hidden="true" fill="currentColor" /> Stop listening</> : <><Mic size={15} aria-hidden="true" /> Start listening</>}
                </button>
                <button type="button" className="nc-button" onClick={clearState} aria-label="Clear latest signal and event log" data-testid="button-clear-state">
                  <RotateCcw size={14} aria-hidden="true" /> Clear
                </button>
              </div>
            </div>
          </div>

        </section>

        {error && (
          <div className="nc-notice" role="alert" data-testid="status-error">
            <strong>{browserSupported ? 'Microphone channel' : 'Browser compatibility'}</strong>
            {error}
          </div>
        )}

        <section className="nc-footer" aria-label="Prototype notes">
          <span><CircleHelp size={13} aria-hidden="true" style={{ verticalAlign: 'text-bottom', marginRight: 7 }} />Use headphones for a more precise read of the quieter signals.</span>
          <span>Speech recognition is used only while live. <a href="https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API" target="_blank" rel="noreferrer">About the browser layer</a></span>
        </section>
      </main>
    </div>
  );
}

function Router() {
  return <Home />;
}

function App() {
  return <Router />;
}

export default App;